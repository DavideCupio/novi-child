<?php
function novi_child_enqueue_styles()
{
    // Dipende dal CSS del parent per avere l’ordine corretto
    wp_enqueue_style(
        'novi-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        ['novi-main-style'],
        wp_get_theme()->get('Version')
    );
}
add_action('wp_enqueue_scripts', 'novi_child_enqueue_styles');